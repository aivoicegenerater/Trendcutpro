
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <header className="text-4xl font-bold mb-6 text-center">TrendCut Pro</header>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="rounded-2xl shadow-md">
          <CardContent className="p-4">
            <h2 className="text-2xl font-semibold mb-2">Client Panel</h2>
            <ul className="space-y-2">
              <li>Sign up / Login</li>
              <li>Submit video project (file upload + brief)</li>
              <li>Select Editing Package</li>
              <li>Make payment (Stripe)</li>
              <li>Track project status</li>
            </ul>
            <Button className="mt-4">Client Dashboard</Button>
          </CardContent>
        </Card>

        <Card className="rounded-2xl shadow-md">
          <CardContent className="p-4">
            <h2 className="text-2xl font-semibold mb-2">Admin Panel</h2>
            <ul className="space-y-2">
              <li>View All Orders</li>
              <li>Assign Editors</li>
              <li>Track Progress</li>
              <li>Mark Orders as Complete</li>
              <li>Send Deliverables</li>
            </ul>
            <Button className="mt-4">Admin Dashboard</Button>
          </CardContent>
        </Card>
      </div>

      <div className="mt-8 text-center">
        <p className="text-sm text-gray-600">
          AI Suggestions, Template Integration & Auto Subtitling coming soon...
        </p>
      </div>
    </div>
  );
}
